const router = require('express').Router();
const verifyUser = require('../initializers/verify');

module.exports = router;